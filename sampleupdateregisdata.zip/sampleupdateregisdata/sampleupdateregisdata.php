<html>

<head>
    <title> Update Registration Data</title>
    <link rel="stylesheet" type="text/css" href="../css/sampleupdateregisdata.css">
</head>


<body  style="background-color:#ced4da" >
 <div class="form1"> <h2> FADTS | UPDATE REGISTRATION DATA</h2> </div>
 <div class="form2">
        <form id="form" class="form" style="width: 55%;">

        <div class="form-row">

            <label class="officer-id1">Officer ID:</label></br>
            <input class="officer-id" type="text" name="Officer-id" id="_officer-id" aria-describedby="validationServer03Feedback" required required size="75"></input></br>
         </div>

        <div class="form-row">
            <label class="nid1">NID:</label></br>
            <input class="nid" type="text" name="Nid" id="_nid" aria-describedby="validationServer03Feedback" required required size="75"></input></br>
        </div>

        <div class="form-row">
            <label class="name1">Name:</label></br>
            <input class="name" type="text" name="Name"  id="_name" aria-describedby="validationServer03Feedback" required required size="75"></input></br></br>
        </div>

         <div class="birth">
                <label class="birth-date1">Birth Date:</label>
                <input class="birth-date" type="text" name="Birth-date" id="_date" aria-describedby="validationServer03Feedback" required></input>
                <small></small>
                <label class="birth-cer1">Birth Certificate No:</label>
                <input class="birth-cer" type="text" name="Birth-cer" id="_cer"  aria-describedby="validationServer03Feedback" required></input>
         </div>

            <div class="form-row">
                    <label class="email1">Email address:</label></br>
                    <input class="email" type="text" name="Email" id="_email" placeholder="name@example.com" required size="75">
                </div>

            <div class="form-row">
            <label class="region">Region:</label></br>
            <select class="option1" name="region" id="_region" aria-describedby="validationServer03Feedback" required>
                <option value="">--SELECT--</option>
                <option value="volvo">Volvo</option>
                <option value="saab">Saab</option>
                <option value="mercedes">Mercedes</option>
                <option value="audi">Audi</option>
            </select>
            </div></br>


            <div class="Job-set">
                <label class="job1" class="job">Job:</label>
                <input class="job" type="text" name="Job" id="_job" aria-describedby="validationServer03Feedback" required ></input>
                <label class="job-type1">Job Type:</label>
                <input class="job-type" type="text" name="Job-type" id="_job-type" aria-describedby="validationServer03Feedback" required></input>
            </div>


           

         <div class="form-row">
                <label class="civil-status1">Civil Status:</label></br>
                <input class="civil-status" type="text" name="Civil-status" id="_civil-status" aria-describedby="validationServer03Feedback" required required size="75"></input></br>
        </div>
            
            <div class="form-group">
            <div class="phone-set">
                <label class="phone-numbera1" class="phone-number">Phone Number 1:</label></br>
                <input class="phone-numbera" type="text" name="Phone-numbera" id="_phone-numbera" aria-describedby="validationServer03Feedback" required required size="75"></input></br>
                </div>
             </div> 
             <div class="form-group">
            <div class="phone-set">
                <label class="phone-numberb1" class="phone-number">Phone Number 2:</label></br>
                <input class="phone-numberb" type="text" name="Phone-numberb" id="_phone-numberb" aria-describedby="validationServer03Feedback" required required size="75"></input></br>
                </div>
             </div> 
            <div class="form-group">
                <label class="trustee">Trustee:</label> </br>
                <select class="option2" name="Trustee" id="_trustee" aria-describedby="validationServer03Feedback" required></br>
                    <option value="">--SELECT--</option>
                    <option value="volvo">Volvo</option>
                    <option value="saab">Saab</option>
                    <option value="mercedes">Mercedes</option>
                    <option value="audi">Audi</option>
                </select>

            </div>
            


            <div class ='buttons'>
                    <br>
                    <button type="submit" class='confirm-button btn btn-primary '>Update</button>
                    <button type="cancel" class='cancel-button btn btn-primary'>Cancel</button>
                    <button class='view-list-button btn btn-primary'>View List</button>
                </div>
 

        </form>

    </div>



</body>

    <script src="../Js/addpeople.js"></script>
</html>