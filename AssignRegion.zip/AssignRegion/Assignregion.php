<!DOCTYPE html>
<html>
<head> <title>Update officer </title>
<link rel="stylesheet" type="text/css" href="../css/Assignregion.css">

</head>
<body  style="background-color:#ced4da" >
 <div class="form1"> <h2>FADTS | ASSIGN REGION</h2> </div>
 <div class="form2">
        <form id="form" class="form" style="width: 55%;">
            

                <div class="form-row">

                    <label class="region1"><b>Region Name:</b></label></br>
                    <input class="region" type="text" name="Region" id='_region' aria-describedby="validationServer03Feedback" required size="75"></input>
                </div></br>

                <div class="form-row">
                    <label class="position1"><b>Position:</b></label></br>
                    <input class="position" type="text" name="Position" id="_position" aria-describedby="validationServer03Feedback" placeholder="(Optional)" required size="75">
                </div></br>

                <div class="form-row">
                    <label class="regionlist"><b>Matching Region List:</b></label></br>
                    <select class="option1" name="regionlist" id="_regionlist" required>
                        <option value="">--SELECT--</option>
                        <option value="volvo">Region 1</option>
                        <option value="saab">Region 2</option>
                        <option value="mercedes">Region 3</option>
                        <option value="audi">Region 4</option>
                    </select>
                </div></br>

                <div class ="buttons">
                    
                    <button type="submit" class='confirm-button btn btn-primary '>Submit</button>
                    <button type="cancel" class='cancel-button btn btn-primary'>Cancel</button>
                </div>

         
        </form>

    </div>

</body>
</html>