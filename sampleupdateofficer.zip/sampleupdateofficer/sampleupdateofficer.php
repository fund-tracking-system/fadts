<!DOCTYPE html>
<html>
<head> <title>Update officer </title>
    <link rel="stylesheet" type="text/css" href="../css/sample1updateofficer.css">

</head>
<body  style="background-color:#ced4da" >
 <div class="form1"> <h2>FADTS | Update Officer</h2> </div>
 <div class="form2">
        <form id="form" class="form" style="width: 55%;">
            

                <div class="form-row">

                    <label class="nid1"><b>NID:</b></label></br>
                    <input class="nid" type="text" name="Nid" id='_nid' aria-describedby="validationServer03Feedback" required size="75"></input>
                </div></br>

                <div class="form-group">
                    <label class="email1"><b>Email address:</b></label></br>
                    <input class="email" type="text" name="Email" id="_email" placeholder="name@example.com" required size="75">
                </div></br>

                <div class="form-row">
                    <label class="region"><b>Region:</b></label></br>
                    <select class="option1" name="region" id="_region" required>
                        <option value="">--SELECT--</option>
                        <option value="volvo">Volvo</option>
                        <option value="saab">Saab</option>
                        <option value="mercedes">Mercedes</option>
                        <option value="audi">Audi</option>
                    </select>
                </div></br>

                <div class="form-row">

                    <label class="position"><b>Position:</b></label></br>
                    <select class="option2" name="position" id="_position" required>
                        <option value="">--SELECT--</option>
                        <option value="volvo">Volvo</option>
                        <option value="saab">Saab</option>
                        <option value="mercedes">Mercedes</option>
                        <option value="audi">Audi</option>
                    </select>
                </div></br>

                <div class="form-row">
                    <label class="civil-status"><b>Civil Status:</b></label>
                    <input class="civilstatus" type="text" name="CivilStatus" id="_civilStatus" aria-describedby="validationServer03Feedback" required size="75"></input>
                </div></br>
                <div class="form-row">
                    <label class="phone-number"><b>Phone Number:</b></label></br>
                    <input class="phonenumber" type="text"  name="Phonenumber" id='_phoneNumber' aria-describedby="validationServer03Feedback" required size="75"></input>
                </div></br>
                <div class ="buttons">
                    
                    <button type="submit" class='confirm-button btn btn-primary '>Update</button>
                    <button type="cancel" class='cancel-button btn btn-primary'>Cancel</button>
                    <button class='view-list-button btn btn-primary'>View List</button>
                </div>

         
        </form>

    </div>

</body>
</html>