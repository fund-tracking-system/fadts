<html>

<head>
    <title> Update Registration Data</title>
    <link rel="stylesheet" type="text/css" href="../css/addPeople.css">
    <link rel="stylesheet" type="text/css" href="../css/logFog.css">
</head>


<body style="background-color:#ced4da">
    <div class="disaster-form">
    
        <form id="form" class="form">
        <h1> FADTS | UPDATE REGISTRATION DATA</h2>

        <fieldset  style="background-color:#fffef4;">
        <div class="form-row">
            <label for="officer-id">Officer ID:</label>
            <input class="form-control" id="officer-id" aria-describedby="validationServer03Feedback" required></input>
            </div>
        <div class="form-row">
            <label for="nid">NID:</label>
            <input class="form-control" id='nid' aria-describedby="validationServer03Feedback" required></input>
            </div>
        <div class="form-row">
            <label for="name">Name:</label>
            <input class="form-control" id="name" aria-describedby="validationServer03Feedback" required></input>
            <div class='birth'>
                <label for="birth-date">Birth Date:</label>
                <input class="form-control" id='date' aria-describedby="validationServer03Feedback" required></input>
                <small></small>
                <label for="birth-date">Birth Certificate No:</label>
                <input class="form-control"id='date' aria-describedby="validationServer03Feedback" required></input>


            </div>
            </div>

            <div class="form-row">
                    <label for="exampleFormControlInput1"><b>Email address</b></label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                </div>

            <label for="region">Region:</label>
            <select class="form-control" name="region" id="region" aria-describedby="validationServer03Feedback" required>
                <option value="volvo">Volvo</option>
                <option value="saab">Saab</option>
                <option value="mercedes">Mercedes</option>
                <option value="audi">Audi</option>
            </select>


            <div class='Job-set'>
                <label class='job-label' for="job">Job:</label>
                <input class="form-control" id='job' aria-describedby="validationServer03Feedback" required></input>
                <label for='job-type'>Job Type:</label>
                <input class="form-control" id='job-type' aria-describedby="validationServer03Feedback" required></input>
            </div>


           

         <div class="form-row">
                <label for="civil-status">Civil Status:</label>
                <input class="form-control" id="civil-status" aria-describedby="validationServer03Feedback" required></input>
        </div>
            
            <div class="form-group">
            <div class='phone-set'>
                <label class='phone-number-label' for="phone-number">Phone Number 1:</label>
                <input class="form-control" id='phone-number' aria-describedby="validationServer03Feedback" required></input>
                </div>
             </div> 
             <div class="form-group">
            <div class='phone-set'>
                <label class='phone-number-label' for="phone-number">Phone Number 2:</label>
                <input class="form-control" id='phone-number' aria-describedby="validationServer03Feedback" required></input>
                </div>
             </div> 
            <div class="form-group">
                <label class = 'trustee-label' for="trustee">Trustee:</label> 
                <select class="form-control" name="trustee" id="trustee" aria-describedby="validationServer03Feedback" required>
                    <option value="volvo">Volvo</option>
                    <option value="saab">Saab</option>
                    <option value="mercedes">Mercedes</option>
                    <option value="audi">Audi</option>
                </select>

            </div>
            


            <div class ='buttons'>
                    <br>
                    <button type="submit" class='confirm-button btn btn-primary '>Update</button>
                    <button type="cancel" class='cancel-button btn btn-primary'>Cancel</button>
                    <button class='view-list-button btn btn-primary'>View List</button>
                </div>
        </fieldset> 

        </form>

    </div>



</body>

    <script src="../Js/addpeople.js"></script>
</html>