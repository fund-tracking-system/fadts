<!DOCTYPE html>
<html>
<head> <title>Update officer </title>
    <link rel="stylesheet" type="text/css" href="../css/updateofficer.css">
    <link rel="stylesheet" type="text/css" href="../css/logFog.css">
</head>
<body  style="background-color:#ced4da" >
 <div class="form1">
        <form id="form" class="form" style="width: 55%;">

            <h2>FADTS | Update Officer</h2>
            <fieldset style="background-color:#fffef4;">

                <div class="form-row">

                    <label for="nid"><b>NID:</b></label>
                    <input class="form-control " name="nid" id='nid' aria-describedby="validationServer03Feedback" required></input>
                </div>

                <div class="form-group">
                    <label for="email"><b>Email address</b></label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required>
                </div>

                <div class="form-row">
                    <label for="region"><b>Region:</b></label>
                    <select class="form-control" name="region" name="region" id="region" required>
                        <option value="">--SELECT--</option>
                        <option value="volvo">Volvo</option>
                        <option value="saab">Saab</option>
                        <option value="mercedes">Mercedes</option>
                        <option value="audi">Audi</option>
                    </select>
                </div>

                <div class="form-row">

                    <label for="position"><b>Position:</b></label>
                    <select class="form-control" name="position" id="position" required>
                        <option value="">--SELECT--</option>
                        <option value="volvo">Volvo</option>
                        <option value="saab">Saab</option>
                        <option value="mercedes">Mercedes</option>
                        <option value="audi">Audi</option>
                    </select>
                </div>

                <div class="form-row">
                    <label for="civil-status"><b>Civil Status:</b></label>
                    <input class="form-control" name="civilStatus" id="civilStatus" aria-describedby="validationServer03Feedback" required></input>
                </div>
                <div class="form-row">
                    <label for="phone-number"><b>Phone Number:</b></label>
                    <input type="number" class="form-control" name="phoneNumber" id='phoneNumber' aria-describedby="validationServer03Feedback" required></input>
                </div>
                <div class ='buttons'>
                    <br>
                    <button type="submit" class='confirm-button btn btn-primary '>Update</button>
                    <button type="cancel" class='cancel-button btn btn-primary'>Cancel</button>
                    <button class='view-list-button btn btn-primary'>View List</button>
                </div>

            </fieldset>
        </form>

    </div>

</body>
</html>